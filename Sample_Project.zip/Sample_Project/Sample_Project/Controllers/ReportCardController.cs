﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sample_Project.Models;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.OleDb;

namespace Sample_Project.Controllers
{
    public class ReportCardController : Controller
    {
        private ProjectDBEntities db = new ProjectDBEntities();

        public ActionResult Upload()
        {
            ViewBag.PlatformID = new SelectList(db.PlatformMasters, "PlatformID", "PlatformName");
            return View();
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase postedFile)
        {
            string filename = Path.GetFileName(postedFile.FileName);
            ProjectDBEntities db = new ProjectDBEntities();
            var getlist = db.PlatformMasters.ToList();
            SelectList list = new SelectList(getlist, "PlatformID", "PlatformName");
            ViewBag.PlatformMaster = list;

            string ddlitem = Request.Form["PlatformID"].ToString();
            var sv = ddlitem.Contains("IKM").ToString();
            var sv1 = ddlitem.Contains("EBOX").ToString();


            string filePath = string.Empty;
            if (postedFile != null)
            {
                string path = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                filePath = path + Path.GetFileName(postedFile.FileName);
                string extension = Path.GetExtension(postedFile.FileName);
                postedFile.SaveAs(filePath);
                string conString = string.Empty;
                switch (extension)
                {
                    case ".xls": //Excel 97-03.
                        conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                        break;
                    case ".xlsx": //Excel 07 and above.
                        conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                        break;
                }
                DataTable dt = new DataTable();
                conString = string.Format(conString, filePath);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbCommand cmdExcel = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            cmdExcel.Connection = connExcel;

                            //Get the name of First Sheet.
                            connExcel.Open();
                            DataTable dtExcelSchema;
                            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                            connExcel.Close();

                            //Read Data from First Sheet.
                            connExcel.Open();
                            cmdExcel.CommandText = "SELECT * From [" + sheetName + "]";
                            odaExcel.SelectCommand = cmdExcel;
                            odaExcel.Fill(dt);
                            connExcel.Close();
                        }
                    }
                }
                conString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name.
                        sqlBulkCopy.DestinationTableName = "dbo.ReportCard";

                        //[OPTIONAL]: Map the Excel columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("Score", "Score");
                        sqlBulkCopy.ColumnMappings.Add("Score", "ScoreId");
                        sqlBulkCopy.ColumnMappings.Add("ID Number", "CandidateId");

                        sqlBulkCopy.ColumnMappings.Add("Name", "TestTakerName");

                        sqlBulkCopy.ColumnMappings.Add("E-Mail Address", "EMail");
                        //================================ Changed test date in Excel sheet=================================================
                        sqlBulkCopy.ColumnMappings.Add("Test Date", "TestDate");
                        sqlBulkCopy.ColumnMappings.Add("Test ID - unique test code", "TestId");
                        sqlBulkCopy.ColumnMappings.Add("Percentile", "Percentile");
                        sqlBulkCopy.ColumnMappings.Add("Application Indicator", "AppIndicator");
                        sqlBulkCopy.ColumnMappings.Add("Workspeed", "WorkSpeed");
                        sqlBulkCopy.ColumnMappings.Add("Weakness", "Weakness");
                        sqlBulkCopy.ColumnMappings.Add("Proficiency", "Proficiency");
                        sqlBulkCopy.ColumnMappings.Add("Strength", "Strength");
                        sqlBulkCopy.ColumnMappings.Add("Subject Coverage", "SubjectCoverage");
                        sqlBulkCopy.ColumnMappings.Add("Average Subtopic Proficiency Score", "SubTopicProficiency");
                        sqlBulkCopy.ColumnMappings.Add("% Answered", "Answered");
                        // sqlBulkCopy.ColumnMappings.Add("LOB", "Lob");
                        sqlBulkCopy.ColumnMappings.Add("PREPOST", "PrePost");
                        //================================  Experience column in database should be varchar as per the Excel sheet=================================================
                        // sqlBulkCopy.ColumnMappings.Add("exp", "Experience");
                        con.Open();
                        sqlBulkCopy.WriteToServer(dt);
                        con.Close();
                    }
                }

                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        sqlBulkCopy.DestinationTableName = "dbo.TestMaster";
                        sqlBulkCopy.ColumnMappings.Add("Test ID - unique test code", "SkuId");
                        sqlBulkCopy.ColumnMappings.Add("Test Name", "SkuName");
                        //sqlBulkCopy.ColumnMappings.Add()

                        con.Open();
                        sqlBulkCopy.WriteToServer(dt);
                        con.Close();
                    }
                }

                ViewBag.Message = "Excel data successfully imported! :)";
            }
            else
            {
                ViewBag.Error = "Kindly select an Excel file!!";
            }
            return View();
        }

        // GET: ReportCard
        public ActionResult Index()
        {
            return View();
        }

        // GET: ReportCard/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ReportCard/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ReportCard/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportCard/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ReportCard/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportCard/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ReportCard/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
